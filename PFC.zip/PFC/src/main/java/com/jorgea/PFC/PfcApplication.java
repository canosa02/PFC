package com.jorgea.PFC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PfcApplication {

	public static void main(String[] args) {
		SpringApplication.run(PfcApplication.class, args);
	}

}
