package com.jorgea.PFC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PfcApplicationTests {

	@Test
	void contextLoads() {
	}

}
